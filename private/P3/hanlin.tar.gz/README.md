Personal Information:
Name: Hanlin Wang
CS Login: hanlin
Wisc ID: 9086237956
Wisc Netid: hwang2377
Email: hwang2377@wisc.edu


Implementation Todo:

- fg failed
- bg failed


